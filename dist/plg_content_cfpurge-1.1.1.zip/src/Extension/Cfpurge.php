<?php
/**
 * @package     plg_content_cfpurge
 * @author      Marco Galassi (WebG)
 * @copyright   (C) 2026 Marco Galassi / WebG
 * @license     GNU General Public License version 2 or later
 *
 * Su creazione / modifica / cambio stato / cancellazione di un articolo svuota la
 * cache Cloudflare (purge_everything) della zona configurata. Ogni evento è
 * attivabile/disattivabile dai parametri. Best-effort: se il purge fallisce non
 * blocca mai il salvataggio.
 */

namespace WebG\Plugin\Content\Cfpurge\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Cfpurge extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = false;

    /** Evita purge multipli nella stessa richiesta. */
    private static bool $alreadyPurged = false;

    public static function getSubscribedEvents(): array
    {
        return [
            'onContentAfterSave'   => 'onAfterSave',
            'onContentChangeState' => 'onChangeState',
            'onContentAfterDelete' => 'onAfterDelete',
        ];
    }

    public function onAfterSave(Event $event): void
    {
        if (!$this->isArticle($event)) {
            return;
        }

        // onContentAfterSave copre sia creazione sia modifica: distingui con isNew.
        $isNew = (bool) $event->getArgument('isNew', false);
        $param = $isNew ? 'on_create' : 'on_update';

        if ((int) $this->params->get($param, 1) === 1) {
            $this->purgeEverything();
        }
    }

    public function onChangeState(Event $event): void
    {
        if ($this->isArticle($event) && (int) $this->params->get('on_state', 1) === 1) {
            $this->purgeEverything();
        }
    }

    public function onAfterDelete(Event $event): void
    {
        if ($this->isArticle($event) && (int) $this->params->get('on_delete', 1) === 1) {
            $this->purgeEverything();
        }
    }

    private function isArticle(Event $event): bool
    {
        $context = (string) $event->getArgument('context', '');

        return strpos($context, 'com_content.article') === 0
            || strpos($context, 'com_content.form') === 0;
    }

    private function purgeEverything(): void
    {
        if (self::$alreadyPurged) {
            return;
        }

        $zone  = trim((string) $this->params->get('zone_id', ''));
        $token = trim((string) $this->params->get('api_token', ''));

        if ($zone === '' || $token === '') {
            return;
        }

        // Hardening difensivo: zone nell'URL (encode del segmento), token nell'header
        // (rimuovi caratteri di controllo = anti header-injection).
        $zone  = rawurlencode($zone);
        $token = preg_replace('/[\x00-\x1F\x7F]+/', '', $token);

        try {
            (new HttpFactory())->getHttp()->post(
                'https://api.cloudflare.com/client/v4/zones/' . $zone . '/purge_cache',
                json_encode(['purge_everything' => true]),
                [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ]
            );

            self::$alreadyPurged = true;
        } catch (\Throwable $e) {
            // best-effort, silenzioso: non interrompere il salvataggio.
        }
    }
}
