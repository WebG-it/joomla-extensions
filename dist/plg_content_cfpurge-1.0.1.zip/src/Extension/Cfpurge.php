<?php
/**
 * @package     plg_content_cfpurge
 * @author      Marco Galassi (WebG)
 * @copyright   (C) 2026 Marco Galassi / WebG
 * @license     GNU General Public License version 2 or later
 *
 * Su salvataggio / cambio stato / cancellazione di un articolo svuota la cache
 * Cloudflare (purge_everything) della zona configurata. Best-effort: se il purge
 * fallisce non blocca mai il salvataggio.
 */

namespace WebG\Plugin\Content\Cfpurge\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Cfpurge extends CMSPlugin implements SubscriberInterface
{
    /**
     * Non serve caricare file di lingua: le etichette sono nel manifest.
     */
    protected $autoloadLanguage = false;

    /**
     * Evita purge multipli nella stessa richiesta (save + changeState insieme).
     */
    private static bool $alreadyPurged = false;

    public static function getSubscribedEvents(): array
    {
        return [
            'onContentAfterSave'   => 'onArticleChange',
            'onContentChangeState' => 'onArticleChange',
            'onContentAfterDelete' => 'onArticleChange',
        ];
    }

    public function onArticleChange(Event $event): void
    {
        if (self::$alreadyPurged) {
            return;
        }

        $context = (string) $event->getArgument('context', '');

        // Solo articoli di com_content (backend o invio da form frontend).
        if (strpos($context, 'com_content.article') !== 0
            && strpos($context, 'com_content.form') !== 0) {
            return;
        }

        $this->purgeEverything();
    }

    private function purgeEverything(): void
    {
        $zone  = trim((string) $this->params->get('zone_id', ''));
        $token = trim((string) $this->params->get('api_token', ''));

        if ($zone === '' || $token === '') {
            return;
        }

        try {
            $http = (new HttpFactory())->getHttp();
            $http->post(
                'https://api.cloudflare.com/client/v4/zones/' . $zone . '/purge_cache',
                json_encode(['purge_everything' => true]),
                [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ]
            );

            self::$alreadyPurged = true;
        } catch (\Throwable $e) {
            // best-effort, silenzioso: non interrompere il salvataggio.
        }
    }
}
