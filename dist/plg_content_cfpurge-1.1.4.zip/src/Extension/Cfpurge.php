<?php

/**
 * @package     plg_content_cfpurge
 * @author      Marco Galassi (WebG)
 * @copyright   (C) 2026 Marco Galassi / WebG
 * @license     GNU General Public License version 2 or later
 *
 * Purges the Cloudflare cache (purge_everything) when an article is created, updated,
 * changes state or is deleted. Each event can be toggled on/off in the parameters.
 * Best-effort: a failed purge never blocks the article save.
 */

namespace WebG\Plugin\Content\Cfpurge\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Cfpurge extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = true;

    /** Avoid multiple purges within the same request. */
    private static bool $alreadyPurged = false;

    public static function getSubscribedEvents(): array
    {
        return [
            'onContentAfterSave'   => 'onAfterSave',
            'onContentChangeState' => 'onChangeState',
            'onContentAfterDelete' => 'onAfterDelete',
        ];
    }

    public function onAfterSave(Event $event): void
    {
        if (!$this->isArticle($event)) {
            return;
        }

        // onContentAfterSave covers both creation and update: tell them apart with isNew.
        $isNew = (bool) $event->getArgument('isNew', false);
        $param = $isNew ? 'on_create' : 'on_update';

        if ((int) $this->params->get($param, 1) === 1) {
            $this->purgeEverything();
        }
    }

    public function onChangeState(Event $event): void
    {
        if ($this->isArticle($event) && (int) $this->params->get('on_state', 1) === 1) {
            $this->purgeEverything();
        }
    }

    public function onAfterDelete(Event $event): void
    {
        if ($this->isArticle($event) && (int) $this->params->get('on_delete', 1) === 1) {
            $this->purgeEverything();
        }
    }

    private function isArticle(Event $event): bool
    {
        $context = (string) $event->getArgument('context', '');

        return strpos($context, 'com_content.article') === 0
            || strpos($context, 'com_content.form') === 0;
    }

    private function purgeEverything(): void
    {
        if (self::$alreadyPurged) {
            return;
        }

        $zone  = trim((string) $this->params->get('zone_id', ''));
        $token = trim((string) $this->params->get('api_token', ''));

        if ($zone === '' || $token === '') {
            return;
        }

        // Defensive hardening: the zone goes into the URL (encode the path segment),
        // the token goes into a header (strip control characters = anti header-injection).
        $zone  = rawurlencode($zone);
        $token = preg_replace('/[[:cntrl:]]+/', '', $token);

        try {
            (new HttpFactory())->getHttp()->post(
                'https://api.cloudflare.com/client/v4/zones/' . $zone . '/purge_cache',
                json_encode(['purge_everything' => true]),
                [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ]
            );

            self::$alreadyPurged = true;
        } catch (\Throwable $e) {
            // best-effort, silent: never interrupt the article save.
        }
    }
}
